
import React, { useState } from 'react';
import Home from './Home';
import Watchlist from './Watchlist';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [watchlist, setWatchlist] = useState([]);

  const toggleDarkMode = () => setDarkMode(!darkMode);

  const addToWatchlist = (movie) => {
    if (!watchlist.find((m) => m.title === movie.title)) {
      setWatchlist([...watchlist, movie]);
    }
  };

  const removeFromWatchlist = (title) => {
    setWatchlist(watchlist.filter((movie) => movie.title !== title));
  };

  return (
    <div className={darkMode ? 'app dark' : 'app'}>
      <Router>
        <nav className="navbar">
          <h1>IMDb Clone</h1>
          <div className="nav-links">
            <Link to="/">Home</Link>
            <Link to="/watchlist">Watchlist ({watchlist.length})</Link>
            <button onClick={toggleDarkMode} className="toggle-btn">
              {darkMode ? '☀️' : '🌙'}
            </button>
          </div>
        </nav>
        <Routes>
          <Route
            path="/"
            element={
              <Home
                addToWatchlist={addToWatchlist}
                watchlist={watchlist}
              />
            }
          />
          <Route
            path="/watchlist"
            element={
              <Watchlist
                watchlist={watchlist}
                removeFromWatchlist={removeFromWatchlist}
              />
            }
          />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
