import React from 'react';

function Watchlist({ watchlist, removeFromWatchlist }) {
  return (
    <div className="container">
      <h2>My Watchlist</h2>
      <div className="grid">
        {watchlist.map((movie) => (
          <div key={movie.title} className="card">
            <img src={movie.poster} alt={movie.title} />
            <h2>{movie.title} ({movie.year})</h2>
            <p>{movie.category}</p>
            <div className="stars">
              {Array.from({ length: 5 }, (_, i) => (
                <span key={i} className={i < movie.rating ? 'filled' : ''}>★</span>
              ))}
            </div>
            <button onClick={() => removeFromWatchlist(movie.title)}>Remove</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Watchlist;
