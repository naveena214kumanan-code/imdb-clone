import React, { useState } from 'react';

const movies = [
  {
    title: 'Interstellar',
    year: 2014,
    category: 'Sci-Fi',
    rating: 5,
    poster: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSngBJ0B7UDrLUkDlp6DCQLsEYuWR-DiHwbnxFFCniB3HiP3f3NZmR1-lKSC34ge6YXu4LX'
  },
  {
    title: 'The Dark Knight',
    year: 2008,
    category: 'Action',
    rating: 5,
    poster: 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTfE_qrYMBZ_JB8om-34WGaZARhpX26yWRttqIDvn4_7l--UzX8mxKcPrc59IcvTpEA_G8gPA'
  },
  {
    title: 'Inception',
    year: 2010,
    category: 'Thriller',
    rating: 5,
    poster: 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRRyuWmayVBvqjd1MxTKpRgauq2cCtUzb7Q9QvaFTkAuxAU_EYMoCE3wBuJeftxIzf0grreIw'
  },
  {
    title: 'Jai Bhim',
    year: 2021,
    category: 'Drama',
    rating: 4,
    poster: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTFbXxEfLTuFL6-r184rnD_o3DzqThzc7naXvOXVLbG6gHyN1Td3CU9hZEi9JjlEiF4G75gSw'
  },
  {
    title: '96',
    year: 2018,
    category: 'Romance',
    rating: 4,
    poster: 'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTJi8r3p1ofcc8GwLAjqrENm2YYAOTGOHSnc7jV9UMtSpR1k12D'
  },
  {
    title: 'Vikram',
    year: 2022,
    category: 'Action',
    rating: 4,
    poster: 'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQVn0y7RuNHnktmebSF6Uf_bv6Ue5ZxMmrRR1I_Yz9Bvs51_P1AMV5ku8qB98PmOVTFK_oh'
  },
];

function Home({ addToWatchlist, watchlist }) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');

  const filtered = movies.filter((movie) => {
    return (
      (category === 'All' || movie.category === category) &&
      movie.title.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="container">
      <div className="controls">
        <input
          type="text"
          placeholder="Search movies..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option>All</option>
          <option>Action</option>
          <option>Drama</option>
          <option>Romance</option>
          <option>Thriller</option>
          <option>Sci-Fi</option>
        </select>
      </div>

      <div className="grid">
        {filtered.map((movie) => (
          <div key={movie.title} className="card">
            <img src={movie.poster} alt={movie.title} />
            <h2>{movie.title} ({movie.year})</h2>
            <p>{movie.category}</p>
            <div className="stars">
              {Array.from({ length: 5 }, (_, i) => (
                <span key={i} className={i < movie.rating ? 'filled' : ''}>★</span>
              ))}
            </div>
            <button onClick={() => addToWatchlist(movie)}>
              {watchlist.find((m) => m.title === movie.title) ? 'Added' : 'Add to Watchlist'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;
